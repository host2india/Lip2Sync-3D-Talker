#!/bin/bash
echo start