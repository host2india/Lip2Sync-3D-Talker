Templates info
